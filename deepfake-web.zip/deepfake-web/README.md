# Veritas — Deepfake Detector Web App

A React + Flask web application converted from the original Tkinter
desktop app. All detection logic — model loading, inference, and
classical forensic analysis — is preserved exactly as written in the
original source; only the UI layer changed.

## Architecture Summary

```
Browser (React SPA)
   │  Axios HTTP calls
   ▼
Flask API  ──────────────►  detector.py (SigLIP + ViT-v2 + classical forensics)
   │                              (unmodified detection logic)
   ▼
CSV history log + JSON result store (backend/data/)
```

- **Detection logic** lives untouched in `backend/detector.py` — the same
  `load_image`, `analyze_ela`, `analyze_noise`, `analyze_metadata`,
  `analyze_frequency`, `analyze_texture`, `run_siglip`, `run_vit`, and
  `compute_verdict` functions from the original Tkinter app.
- **Tkinter has been removed entirely.** No `tkinter` import remains
  anywhere in the project.
- The Flask layer (`app.py`, `routes.py`) is a thin HTTP wrapper that
  calls those same functions and returns JSON.
- History is logged to `backend/data/history.csv` (the 5 columns
  requested: filename, timestamp, verdict, confidence, processing_time).
  Full per-analysis detail (findings, model scores, category breakdown)
  is kept in `backend/data/results.json`, keyed by the same id, so the
  Summary/Report page can show complete detail for any past run.

## Folder Structure

```
deepfake-web/
├── backend/
│   ├── app.py              # Flask entrypoint
│   ├── routes.py           # API endpoints
│   ├── detector.py         # UNCHANGED detection/forensics logic
│   ├── history_logger.py   # CSV read/write
│   ├── results_store.py    # Full-detail JSON store (supports /api/result, /api/report)
│   ├── requirements.txt
│   └── data/                # created at runtime: history.csv, results.json, uploads/
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── pages/
        │   ├── Home.jsx / .css
        │   ├── Analysis.jsx / .css
        │   ├── History.jsx / .css
        │   └── Summary.jsx / .css
        ├── components/
        │   ├── NavBar.jsx / .css
        │   ├── ConfidenceRing.jsx / .css
        │   └── VerdictBadge.jsx / .css
        └── services/
            └── api.js       # Axios client
```

## API Endpoints

| Method | Endpoint              | Description                                  |
|--------|------------------------|-----------------------------------------------|
| POST   | `/api/analyze`         | Upload an image (`multipart/form-data`, field `image`), runs the full detection pipeline, logs + returns the result |
| GET    | `/api/history`         | Returns all past analyses from the CSV log    |
| GET    | `/api/result/<id>`     | Full detail for one past analysis             |
| GET    | `/api/report/<id>`     | Same as `/api/result/<id>` (report-view alias) |
| GET    | `/api/health`          | Health check                                   |

## Routing

| Path           | Page      |
|----------------|-----------|
| `/`            | Home      |
| `/analysis`    | Analysis  |
| `/history`     | History   |
| `/result/:id`  | Summary   |

## Run Instructions

### 1. Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

The API starts on **http://localhost:5000**.

> First run will download the SigLIP and ViT-v2 model weights from
> Hugging Face (~700 MB total). If `torch`/`transformers` aren't
> installed or the download fails, the app automatically falls back
> to classical-forensics-only mode — exactly like the original
> desktop app did.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

The app opens on **http://localhost:5173**. It talks to the backend
at `http://localhost:5000` by default — override with a `.env` file
(see `.env.example`) if your backend runs elsewhere.

### 3. Production build (optional)

```bash
cd frontend
npm run build       # outputs static files to frontend/dist/
```

Serve `frontend/dist/` with any static host, and run the Flask API
behind a production WSGI server (e.g. gunicorn) instead of the dev
server.

## Notes on Branding

The original UI mockups were used only for layout, component
structure, navigation, color palette, and UX patterns. All
government/law-enforcement branding, agency names, badge numbers,
case IDs, and authenticity-certification styling from those mockups
were intentionally **not** carried into this build. The app ships
under neutral product branding ("Veritas") with a results page that
is clearly labeled as an internal analysis summary — not an official
certificate of any kind.
