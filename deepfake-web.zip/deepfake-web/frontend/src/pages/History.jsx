import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import VerdictBadge from "../components/VerdictBadge";
import { getHistory, getErrorMessage } from "../services/api";
import "./History.css";

export default function History() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState([]);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    getHistory()
      .then((data) => {
        setEntries(data.history || []);
        setStatus("done");
      })
      .catch((err) => {
        setError(getErrorMessage(err));
        setStatus("error");
      });
  }, []);

  const filtered = useMemo(() => {
    if (!query.trim()) return entries;
    const q = query.toLowerCase();
    return entries.filter(
      (e) =>
        e.filename?.toLowerCase().includes(q) ||
        e.verdict?.toLowerCase().includes(q) ||
        e.timestamp?.toLowerCase().includes(q)
    );
  }, [entries, query]);

  return (
    <div className="history">
      <header className="history__header">
        <div>
          <h1 className="history__title">Analysis History</h1>
          <p className="history__subtitle">
            {status === "done" ? `${entries.length} total scans logged` : "Loading…"}
          </p>
        </div>
        <input
          className="history__search"
          type="text"
          placeholder="Search by filename, verdict, or date…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </header>

      {status === "error" && <p className="history__error">{error}</p>}

      {status === "done" && entries.length === 0 && (
        <div className="history__empty">
          <p>No analyses yet.</p>
          <button className="btn btn--primary" onClick={() => navigate("/")}>
            Run your first analysis
          </button>
        </div>
      )}

      {status === "done" && entries.length > 0 && (
        <div className="history__table-wrap">
          <table className="history__table">
            <thead>
              <tr>
                <th>Filename</th>
                <th>Timestamp</th>
                <th>Verdict</th>
                <th>Confidence</th>
                <th>Processing Time</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((entry) => (
                <tr key={entry.id} onClick={() => navigate(`/result/${entry.id}`)}>
                  <td className="history__filename">{entry.filename}</td>
                  <td className="mono">{entry.timestamp}</td>
                  <td>
                    <VerdictBadge verdict={entry.verdict} />
                  </td>
                  <td>{entry.confidence}</td>
                  <td className="mono">{entry.processing_time}s</td>
                  <td className="history__open">Open →</td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <p className="history__no-match">No entries match "{query}".</p>
          )}
        </div>
      )}
    </div>
  );
}
