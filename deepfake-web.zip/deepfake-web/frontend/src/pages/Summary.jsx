import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import ConfidenceRing from "../components/ConfidenceRing";
import VerdictBadge from "../components/VerdictBadge";
import { getReport, getErrorMessage } from "../services/api";
import "./Summary.css";

const MODULE_LABELS = {
  ela: "Error Level Analysis",
  noise: "Noise Analysis",
  metadata: "Metadata",
  frequency: "Frequency (FFT)",
  texture: "Texture (LBP)",
};

export default function Summary() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [report, setReport] = useState(null);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setStatus("loading");
    getReport(id)
      .then((data) => {
        if (!cancelled) {
          setReport(data);
          setStatus("done");
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(getErrorMessage(err));
          setStatus("error");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (status === "loading") {
    return <div className="summary summary--centered">Loading report…</div>;
  }

  if (status === "error") {
    return (
      <div className="summary summary--centered">
        <p className="summary__error">{error}</p>
        <Link className="btn btn--primary" to="/history">
          Back to History
        </Link>
      </div>
    );
  }

  return (
    <div className="summary">
      <div className="summary__card">
        <header className="summary__header">
          <div>
            <span className="summary__eyebrow">Analysis Summary</span>
            <h1 className="summary__title">{report.filename}</h1>
            <p className="summary__timestamp mono">{report.timestamp}</p>
          </div>
          <button className="btn btn--ghost" onClick={() => window.print()}>
            Print / Save PDF
          </button>
        </header>

        <section className="summary__verdict-block">
          <ConfidenceRing fakePct={report.fake_pct} size={150} />
          <div className="summary__verdict-info">
            <VerdictBadge verdict={report.verdict} confidence={report.confidence} />
            <p className="summary__caveat">
              AI-assisted analysis. Not suitable as sole evidence for legal or
              critical decisions — consult a digital forensics expert for
              high-stakes determinations.
            </p>
          </div>
        </section>

        <section className="summary__section">
          <h2 className="summary__section-title">Model Information</h2>
          <div className="summary__grid">
            <EngineCard
              name="SigLIP"
              accuracy="94.4%"
              available={report.engine_status?.siglip?.available}
              score={report.siglip_fake}
            />
            <EngineCard
              name="ViT-v2"
              accuracy="92.1%"
              available={report.engine_status?.vit?.available}
              score={report.vit_fake}
            />
            <EngineCard
              name="Classical Forensics"
              accuracy={null}
              available={true}
              score={report.classical_score / 100}
              isClassical
            />
          </div>
        </section>

        <section className="summary__section">
          <h2 className="summary__section-title">Category Breakdown</h2>
          <div className="summary__bars">
            {Object.entries(report.category_scores || {}).map(([key, val]) => (
              <div className="summary__bar-row" key={key}>
                <span className="summary__bar-label">{key}</span>
                <div className="summary__bar-track">
                  <div className="summary__bar-fill" style={{ width: `${val}%` }} />
                </div>
                <span className="mono summary__bar-value">{val}%</span>
              </div>
            ))}
          </div>
        </section>

        <section className="summary__section">
          <h2 className="summary__section-title">Forensic Findings</h2>
          <ul className="summary__findings">
            {report.findings?.map((f, i) => (
              <li key={i}>{f}</li>
            ))}
          </ul>
        </section>

        <section className="summary__section">
          <h2 className="summary__section-title">Forensic Module Scores</h2>
          <div className="summary__modules">
            {Object.entries(report.classical || {}).map(([key, val]) => (
              <div className="summary__module-row" key={key}>
                <span>{MODULE_LABELS[key] || key}</span>
                <span className="mono">{Math.round(val.suspicion * 100)}%</span>
              </div>
            ))}
          </div>
        </section>

        <footer className="summary__footer">
          <span>Processing time: {report.processing_time}s</span>
          <span>Report ID: {report.id}</span>
        </footer>
      </div>

      <div className="summary__actions">
        <button className="btn btn--ghost" onClick={() => navigate("/history")}>
          ← Back to History
        </button>
        <button className="btn btn--primary" onClick={() => navigate("/")}>
          Analyze another image
        </button>
      </div>
    </div>
  );
}

function EngineCard({ name, accuracy, available, score, isClassical }) {
  return (
    <div className="engine-card">
      <div className="engine-card__top">
        <span className="engine-card__name">{name}</span>
        {accuracy && <span className="engine-card__accuracy mono">{accuracy} acc.</span>}
      </div>
      {available ? (
        <span className="mono engine-card__score">
          {(score * 100).toFixed(1)}% {isClassical ? "suspicious" : "fake"}
        </span>
      ) : (
        <span className="engine-card__unavailable">Not available for this run</span>
      )}
    </div>
  );
}
