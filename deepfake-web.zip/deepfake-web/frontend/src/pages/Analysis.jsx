import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import ConfidenceRing from "../components/ConfidenceRing";
import VerdictBadge from "../components/VerdictBadge";
import { analyzeImage, getErrorMessage } from "../services/api";
import "./Analysis.css";

const STAGES = [
  "Loading image",
  "Running SigLIP engine",
  "Running ViT-v2 engine",
  "Computing forensic signals",
  "Building ensemble verdict",
];

export default function Analysis() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const file = state?.file;

  const [previewUrl, setPreviewUrl] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | running | done | error
  const [stageIndex, setStageIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const hasStarted = useRef(false);

  useEffect(() => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  useEffect(() => {
    if (!file || hasStarted.current) return;
    hasStarted.current = true;
    runAnalysis();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file]);

  // Cosmetic stage ticker while waiting on the backend (which runs as one call)
  useEffect(() => {
    if (status !== "running") return;
    const interval = setInterval(() => {
      setStageIndex((i) => (i < STAGES.length - 1 ? i + 1 : i));
    }, 1400);
    return () => clearInterval(interval);
  }, [status]);

  async function runAnalysis() {
    setStatus("running");
    setError("");
    try {
      const data = await analyzeImage(file, setProgress);
      setResult(data);
      setStatus("done");
    } catch (err) {
      setError(getErrorMessage(err));
      setStatus("error");
    }
  }

  if (!file) {
    return (
      <div className="analysis analysis--empty">
        <p>No image was provided.</p>
        <button className="btn btn--primary" onClick={() => navigate("/")}>
          Upload an image
        </button>
      </div>
    );
  }

  return (
    <div className="analysis">
      {/* Left: file info + progress */}
      <aside className="analysis__panel analysis__file-panel">
        <h3 className="analysis__panel-title">Source File</h3>
        <div className="analysis__preview">
          {previewUrl && <img src={previewUrl} alt="Uploaded preview" />}
        </div>
        <div className="analysis__meta">
          <div className="analysis__meta-row">
            <span>Filename</span>
            <span className="mono">{file.name}</span>
          </div>
          <div className="analysis__meta-row">
            <span>Size</span>
            <span className="mono">{(file.size / 1024).toFixed(1)} KB</span>
          </div>
          <div className="analysis__meta-row">
            <span>Type</span>
            <span className="mono">{file.type || "unknown"}</span>
          </div>
        </div>

        <div className="analysis__progress-block">
          <h3 className="analysis__panel-title">Pipeline Status</h3>
          {status === "running" && (
            <>
              <div className="analysis__progress-bar">
                <div className="analysis__progress-fill" style={{ width: `${Math.max(progress, 8)}%` }} />
              </div>
              <p className="analysis__stage">
                <span className="analysis__pulse" />
                {STAGES[stageIndex]}…
              </p>
            </>
          )}
          {status === "done" && <p className="analysis__stage analysis__stage--done">Analysis complete</p>}
          {status === "error" && <p className="analysis__stage analysis__stage--error">Analysis failed</p>}
          {status === "idle" && <p className="analysis__stage">Waiting to start…</p>}
        </div>
      </aside>

      {/* Center: verdict + ring */}
      <section className="analysis__panel analysis__center-panel">
        {status === "running" && (
          <div className="analysis__loading">
            <ConfidenceRing fakePct={0} size={160} label="ANALYZING" />
            <p>Running detection engines and forensic checks…</p>
          </div>
        )}

        {status === "error" && (
          <div className="analysis__loading">
            <p className="analysis__error-text">{error}</p>
            <button className="btn btn--primary" onClick={runAnalysis}>
              Retry analysis
            </button>
          </div>
        )}

        {status === "done" && result && (
          <>
            <ConfidenceRing fakePct={result.fake_pct} size={200} />
            <VerdictBadge verdict={result.verdict} confidence={result.confidence} />
            <div className="analysis__stats-row">
              <div className="analysis__stat">
                <span className="analysis__stat-value mono">{result.processing_time}s</span>
                <span className="analysis__stat-label">Processing Time</span>
              </div>
              <div className="analysis__stat">
                <span className="analysis__stat-value mono">{result.classical_score}%</span>
                <span className="analysis__stat-label">Forensic Suspicion</span>
              </div>
            </div>
            <button
              className="btn btn--primary analysis__report-btn"
              onClick={() => navigate(`/result/${result.id}`)}
            >
              View Full Report →
            </button>
          </>
        )}
      </section>

      {/* Right: live findings feed */}
      <aside className="analysis__panel analysis__findings-panel">
        <h3 className="analysis__panel-title">Forensic Findings</h3>
        <div className="analysis__findings-list">
          {status !== "done" && (
            <p className="analysis__findings-empty">
              {status === "running" ? "Findings will appear here as they're detected…" : "—"}
            </p>
          )}
          {status === "done" &&
            result.findings.map((f, i) => (
              <div key={i} className="analysis__finding">
                <span className="analysis__finding-dot" />
                {f}
              </div>
            ))}
        </div>

        {status === "done" && (
          <>
            <h3 className="analysis__panel-title analysis__panel-title--spaced">Engine Scores</h3>
            <div className="analysis__engine-scores">
              <EngineScoreRow label="SigLIP" value={result.siglip_fake} />
              <EngineScoreRow label="ViT-v2" value={result.vit_fake} />
            </div>
          </>
        )}
      </aside>
    </div>
  );
}

function EngineScoreRow({ label, value }) {
  const available = value !== null && value !== undefined;
  const pct = available ? (value * 100).toFixed(1) : null;
  return (
    <div className="analysis__engine-row">
      <span>{label}</span>
      <span className="mono">{available ? `${pct}% fake` : "unavailable"}</span>
    </div>
  );
}
