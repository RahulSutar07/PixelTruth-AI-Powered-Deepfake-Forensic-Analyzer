import { useCallback, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/bmp", "image/webp"];
const MAX_SIZE_MB = 20;

export default function Home() {
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState("");

  const validateAndProceed = useCallback(
    (file) => {
      if (!file) return;
      setError("");

      if (!ALLOWED_TYPES.includes(file.type)) {
        setError("Unsupported file type. Please upload a JPG, PNG, BMP, or WEBP image.");
        return;
      }
      if (file.size / (1024 * 1024) > MAX_SIZE_MB) {
        setError(`File too large. Maximum size is ${MAX_SIZE_MB} MB.`);
        return;
      }

      navigate("/analysis", { state: { file } });
    },
    [navigate]
  );

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    validateAndProceed(e.dataTransfer.files?.[0]);
  };

  return (
    <div className="home">
      <section className="home__hero">
        <div className="home__eyebrow">Media Authenticity Engine</div>
        <h1 className="home__title">
          See what's real.
          <br />
          <span className="home__title-accent">Before you trust it.</span>
        </h1>
        <p className="home__subtitle">
          Upload an image and Veritas runs it through two trained detection
          models plus five classical forensic checks — error-level analysis,
          noise consistency, frequency-domain artifacts, texture, and
          metadata — to flag signs of AI generation or manipulation.
        </p>

        <div
          className={"home__dropzone" + (dragOver ? " home__dropzone--active" : "")}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => inputRef.current?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
          }}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/bmp,image/webp"
            hidden
            onChange={(e) => validateAndProceed(e.target.files?.[0])}
          />
          <div className="home__dropzone-icon">↑</div>
          <div className="home__dropzone-text">
            <strong>Drop an image here</strong> or click to browse
          </div>
          <div className="home__dropzone-hint">JPG, PNG, BMP, WEBP — up to {MAX_SIZE_MB} MB</div>
        </div>

        {error && <p className="home__error">{error}</p>}
      </section>

      <section className="home__engines">
        <div className="home__engine-card">
          <span className="home__engine-tag">Engine 01</span>
          <h3>SigLIP</h3>
          <p>Fine-tuned on 20,000 real/fake images. Reported accuracy 94.4%.</p>
        </div>
        <div className="home__engine-card">
          <span className="home__engine-tag">Engine 02</span>
          <h3>ViT-v2</h3>
          <p>Fine-tuned on 56,000 real/fake images. Reported accuracy 92.1%.</p>
        </div>
        <div className="home__engine-card">
          <span className="home__engine-tag">Engine 03</span>
          <h3>Classical Forensics</h3>
          <p>ELA, noise, FFT, texture and metadata checks act as a tie-breaker.</p>
        </div>
      </section>
    </div>
  );
}
