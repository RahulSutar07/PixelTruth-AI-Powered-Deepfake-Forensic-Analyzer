import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const client = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000, // model inference can take a while on first run
});

/**
 * Upload an image for analysis.
 * @param {File} file
 * @param {(progress: number) => void} onUploadProgress
 */
export async function analyzeImage(file, onUploadProgress) {
  const formData = new FormData();
  formData.append("image", file);

  const response = await client.post("/api/analyze", formData, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (evt) => {
      if (onUploadProgress && evt.total) {
        onUploadProgress(Math.round((evt.loaded / evt.total) * 100));
      }
    },
  });
  return response.data;
}

export async function getHistory() {
  const response = await client.get("/api/history");
  return response.data;
}

export async function getResult(id) {
  const response = await client.get(`/api/result/${id}`);
  return response.data;
}

export async function getReport(id) {
  const response = await client.get(`/api/report/${id}`);
  return response.data;
}

/** Extracts a human-readable message from any axios/network error. */
export function getErrorMessage(error) {
  if (error.response?.data?.error) return error.response.data.error;
  if (error.code === "ECONNABORTED") return "The request timed out. Please try again.";
  if (error.message === "Network Error") return "Could not reach the server. Is the backend running?";
  return error.message || "Something went wrong.";
}
