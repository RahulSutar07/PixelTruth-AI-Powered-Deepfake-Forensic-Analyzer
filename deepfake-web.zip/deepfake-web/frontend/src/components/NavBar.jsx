import { NavLink } from "react-router-dom";
import "./NavBar.css";

const NAV_LINKS = [
  { to: "/", label: "Home" },
  { to: "/analysis", label: "Analysis" },
  { to: "/history", label: "History" },
];

export default function NavBar() {
  return (
    <header className="navbar">
      <div className="navbar__brand">
        <span className="navbar__mark">◆</span>
        <span className="navbar__name">Veritas</span>
        <span className="navbar__tagline">Media Forensics</span>
      </div>
      <nav className="navbar__links">
        {NAV_LINKS.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              "navbar__link" + (isActive ? " navbar__link--active" : "")
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
      <div className="navbar__status">
        <span className="navbar__dot" />
        Engine Online
      </div>
    </header>
  );
}
