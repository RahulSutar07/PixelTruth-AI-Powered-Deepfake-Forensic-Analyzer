import "./ConfidenceRing.css";

/**
 * Circular gauge showing fake-probability percentage.
 * Color shifts green -> amber -> red as fakePct increases.
 */
export default function ConfidenceRing({ fakePct = 0, size = 180, label = "FAKE SCORE" }) {
  const radius = size / 2 - 12;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, fakePct));
  const offset = circumference - (clamped / 100) * circumference;

  let color = "var(--verdict-real)";
  if (clamped >= 55) color = "var(--verdict-fake)";
  else if (clamped >= 38) color = "var(--verdict-mid)";

  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--border)"
          strokeWidth="10"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          className="ring__progress"
        />
      </svg>
      <div className="ring__center">
        <span className="ring__value mono" style={{ color }}>
          {clamped.toFixed(1)}
          <small>%</small>
        </span>
        <span className="ring__label">{label}</span>
      </div>
    </div>
  );
}
