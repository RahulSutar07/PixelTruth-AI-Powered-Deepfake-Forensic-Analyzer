import "./VerdictBadge.css";

/** Maps a verdict string (e.g. "🟢 Likely Real") to a color tier for styling. */
function tierFor(verdict = "") {
  if (verdict.includes("Real")) return "real";
  if (verdict.includes("Likely Fake") || verdict.includes("Deepfake")) return "fake";
  return "mid";
}

export default function VerdictBadge({ verdict, confidence }) {
  const tier = tierFor(verdict);
  return (
    <div className={`verdict-badge verdict-badge--${tier}`}>
      <span className="verdict-badge__text">{verdict}</span>
      {confidence && <span className="verdict-badge__confidence">{confidence} confidence</span>}
    </div>
  );
}
