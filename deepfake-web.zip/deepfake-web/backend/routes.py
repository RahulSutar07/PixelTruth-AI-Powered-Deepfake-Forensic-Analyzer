"""
routes.py
══════════════════════════════════════════════════════════════════
Flask Blueprint exposing the deepfake detector over HTTP.

Endpoints:
  POST /api/analyze        — upload an image, run the detection
                              pipeline, log + return the result
  GET  /api/history         — list all past analyses (from CSV)
  GET  /api/result/<id>     — full detail for one past analysis
  GET  /api/report/<id>     — alias of /api/result/<id> (report view)

This file is UI-agnostic. It calls detector.py's functions exactly
as the original Tkinter app did (load_image → compute_verdict) and
never touches the prediction logic itself.
══════════════════════════════════════════════════════════════════
"""

import os
import time
import uuid
import datetime

import numpy as np
from flask import Blueprint, jsonify, request
from werkzeug.utils import secure_filename

import detector
import history_logger
import results_store


def _to_jsonable(obj):
    """Recursively convert numpy scalar/array types to native Python types
    so the detector's raw output (which freely uses np.float32 etc.) can be
    JSON-serialized. Does not alter any value, only its container type."""
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj

api = Blueprint("api", __name__)

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "bmp", "webp"}
MAX_FILE_SIZE_MB = 20
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "uploads")


def _allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@api.route("/api/analyze", methods=["POST"])
def analyze():
    # ── File presence validation ──────────────────────────────────
    if "image" not in request.files:
        return jsonify({"error": "No image file provided. Expected form field 'image'."}), 400

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not _allowed_file(file.filename):
        return jsonify({
            "error": f"Unsupported file type. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        }), 400

    # ── Size validation ────────────────────────────────────────────
    file.seek(0, os.SEEK_END)
    size_mb = file.tell() / (1024 * 1024)
    file.seek(0)
    if size_mb > MAX_FILE_SIZE_MB:
        return jsonify({"error": f"File too large. Max size is {MAX_FILE_SIZE_MB} MB."}), 400

    # ── Save upload to disk (detector functions need a file path) ──
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    safe_name = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{safe_name}"
    save_path = os.path.join(UPLOAD_DIR, unique_name)
    file.save(save_path)

    try:
        start = time.time()
        pil_img, cv_img = detector.load_image(save_path)
        verdict = detector.compute_verdict(pil_img, save_path, cv_img)
        processing_time = round(time.time() - start, 2)
    except Exception as e:
        return jsonify({"error": f"Analysis failed: {e}"}), 500

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # ── Log summary row to CSV, get its id ──────────────────────────
    history_logger.append_entry(
        filename=safe_name,
        timestamp=timestamp,
        verdict=verdict["primary"],
        confidence=verdict["confidence"],
        processing_time=processing_time,
    )
    entries = history_logger.read_all()
    new_entry_id = entries[-1]["id"]

    # ── Store full detail for the Report/Summary page ───────────────
    full_result = {
        "id": new_entry_id,
        "filename": safe_name,
        "timestamp": timestamp,
        "processing_time": processing_time,
        "verdict": verdict["primary"],
        "confidence": verdict["confidence"],
        "fake_pct": verdict["fake_pct"],
        "findings": verdict["findings"],
        "siglip_fake": verdict["siglip_fake"],
        "vit_fake": verdict["vit_fake"],
        "classical_score": verdict["classical_score"],
        "category_scores": verdict["category_scores"],
        "classical": verdict["classical"],
        "engine_status": detector.engine_status(),
    }
    full_result = _to_jsonable(full_result)
    results_store.save_result(new_entry_id, full_result)

    return jsonify(full_result), 200


@api.route("/api/history", methods=["GET"])
def get_history():
    try:
        entries = history_logger.read_all()
        entries.sort(key=lambda e: e["id"], reverse=True)  # newest first
        return jsonify({"count": len(entries), "history": entries}), 200
    except Exception as e:
        return jsonify({"error": f"Could not read history: {e}"}), 500


def _get_result_or_404(entry_id):
    try:
        entry_id_int = int(entry_id)
    except ValueError:
        return None, jsonify({"error": "Invalid result id."}), 400

    result = results_store.get_result(entry_id_int)
    if result is None:
        return None, jsonify({"error": f"No analysis found with id {entry_id}."}), 404
    return result, None, None


@api.route("/api/result/<entry_id>", methods=["GET"])
def get_result(entry_id):
    result, err_response, status = _get_result_or_404(entry_id)
    if err_response:
        return err_response, status
    return jsonify(result), 200


@api.route("/api/report/<entry_id>", methods=["GET"])
def get_report(entry_id):
    # Same data as /api/result — kept as a distinct route per spec so the
    # frontend's Report/Summary page has a semantically named endpoint.
    result, err_response, status = _get_result_or_404(entry_id)
    if err_response:
        return err_response, status
    return jsonify(result), 200
