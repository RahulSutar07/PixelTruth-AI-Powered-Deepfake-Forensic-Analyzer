"""
app.py
══════════════════════════════════════════════════════════════════
Flask application entrypoint.

Run with:  python app.py
Serves the API on http://localhost:5000
══════════════════════════════════════════════════════════════════
"""

from flask import Flask, jsonify
from flask_cors import CORS

from routes import api


def create_app():
    app = Flask(__name__)
    CORS(app)  # allow the React dev server (different origin) to call the API

    app.register_blueprint(api)

    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok"}), 200

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Endpoint not found."}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"error": "Internal server error."}), 500

    return app


app = create_app()

if __name__ == "__main__":
    print("\n" + "=" * 55)
    print("  Deepfake Detector — Web API")
    print("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=True)
