"""
results_store.py
══════════════════════════════════════════════════════════════════
Stores the FULL analysis result (findings, model scores, category
breakdown, etc.) for each history entry, keyed by the same id used
in history_logger's CSV rows.

The CSV (history_logger.py) only carries the 5 summary columns
requested in the spec. This store carries everything else so the
Report/Summary page can show full detail when revisiting a past
result via GET /api/report/<id> or GET /api/result/<id>.

Backed by a simple JSON file — swappable for a real DB later
without touching routes.py.
══════════════════════════════════════════════════════════════════
"""

import json
import os
import threading

STORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "results.json")

_lock = threading.Lock()


def _ensure_file():
    os.makedirs(os.path.dirname(STORE_FILE), exist_ok=True)
    if not os.path.exists(STORE_FILE):
        with open(STORE_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f)


def _read_all():
    _ensure_file()
    with open(STORE_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_result(entry_id, result_dict):
    """Persist the full result payload under entry_id (string key)."""
    with _lock:
        data = _read_all()
        data[str(entry_id)] = result_dict
        with open(STORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)


def get_result(entry_id):
    """Retrieve the full result payload for entry_id, or None."""
    data = _read_all()
    return data.get(str(entry_id))
