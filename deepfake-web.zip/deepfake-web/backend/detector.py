"""
detector.py
══════════════════════════════════════════════════════════════════
Deepfake Detector Pro v2 — Detection Engine (UI-free)

This module is the ENGINE extracted from the original Tkinter desktop
app. Every detection / forensics function below is preserved exactly
as it was written in the original source (version_1.txt):

  - load_image
  - analyze_ela
  - analyze_noise
  - analyze_metadata
  - analyze_frequency
  - analyze_texture
  - run_siglip
  - run_vit
  - compute_verdict

No prediction algorithm, weighting, threshold, or model call has been
changed. Only Tkinter, threading-for-UI, and GUI display code were
removed — none of that lived in these functions to begin with.

Engine 1 : SigLIP  (prithivMLmods/deepfake-detector-model-v1)
           Reported accuracy : 94.4 %
Engine 2 : ViT-v2  (prithivMLmods/Deep-Fake-Detector-v2-Model)
           Reported accuracy : 92.1 %
Engine 3 : Classical forensics (ELA / Noise / FFT / Texture / Metadata)
           Used as confidence tie-breaker

Strategy : Weighted ensemble — SigLIP 45%, ViT-v2 35%, Classical 20%.
           If a DL model is unavailable, its weight is redistributed
           to the classical forensics score.
══════════════════════════════════════════════════════════════════
"""

import os
import sys
import tempfile
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import cv2
from PIL import Image, ImageChops
from scipy.signal import find_peaks
from skimage.feature import local_binary_pattern
from skimage.filters import gaussian

# ── Deep-learning engines (optional but strongly recommended) ────
HAS_TORCH = False
HAS_SIGLIP = False
HAS_VIT = False

try:
    import torch
    HAS_TORCH = True
    print(f"✅ PyTorch {torch.__version__} loaded")
except ImportError:
    print("⚠️  PyTorch not found — DL engines disabled (accuracy will be lower)")
    print("    Install: pip install torch torchvision")

_siglip_processor = None
_siglip_model = None
_vit_processor = None
_vit_model = None

if HAS_TORCH:
    try:
        from transformers import (
            AutoImageProcessor,
            SiglipForImageClassification,
            ViTForImageClassification,
            ViTImageProcessor,
        )
        print("✅ Transformers loaded")

        # ── Engine 1: SigLIP (94.4 % accuracy) ───────────────────
        print("⏳ Loading SigLIP model (first run downloads ~372 MB)…")
        _siglip_name = "prithivMLmods/deepfake-detector-model-v1"
        _siglip_processor = AutoImageProcessor.from_pretrained(_siglip_name)
        _siglip_model = SiglipForImageClassification.from_pretrained(_siglip_name)
        _siglip_model.eval()
        HAS_SIGLIP = True
        print("✅ SigLIP engine ready")

        # ── Engine 2: ViT-v2 (92.1 % accuracy) ───────────────────
        print("⏳ Loading ViT-v2 model (first run downloads ~330 MB)…")
        _vit_name = "prithivMLmods/Deep-Fake-Detector-v2-Model"
        _vit_processor = ViTImageProcessor.from_pretrained(_vit_name)
        _vit_model = ViTForImageClassification.from_pretrained(_vit_name)
        _vit_model.eval()
        HAS_VIT = True
        print("✅ ViT-v2 engine ready")

    except Exception as e:
        print(f"⚠️  Transformers/model error: {e}")
        print("    Falling back to classical forensics only.")


# ─────────────────────────────────────────────────────────────────
#  DL ENGINES
# ─────────────────────────────────────────────────────────────────

def run_siglip(pil_img):
    """
    Returns fake_probability in [0, 1].
    Label mapping: 0 → fake, 1 → real
    """
    if not HAS_SIGLIP:
        return None
    try:
        inputs = _siglip_processor(images=pil_img, return_tensors="pt")
        with torch.no_grad():
            logits = _siglip_model(**inputs).logits
        probs = torch.nn.functional.softmax(logits, dim=1).squeeze().tolist()
        # index 0 = fake, index 1 = real
        fake_prob = probs[0] if len(probs) == 2 else 0.5
        return float(fake_prob)
    except Exception as e:
        print(f"SigLIP error: {e}")
        return None


def run_vit(pil_img):
    """
    Returns fake_probability in [0, 1].
    Label mapping: depends on model — we read id2label to be safe.
    """
    if not HAS_VIT:
        return None
    try:
        inputs = _vit_processor(images=pil_img, return_tensors="pt")
        with torch.no_grad():
            logits = _vit_model(**inputs).logits
        probs = torch.nn.functional.softmax(logits, dim=1).squeeze().tolist()

        # Determine which index is "deepfake / fake"
        id2label = _vit_model.config.id2label  # {0: 'Realism', 1: 'Deepfake'} typical
        fake_index = None
        for idx, label in id2label.items():
            if 'fake' in str(label).lower() or 'deepfake' in str(label).lower():
                fake_index = int(idx)
                break
        if fake_index is None:
            fake_index = 1  # fallback assumption

        fake_prob = probs[fake_index] if fake_index < len(probs) else 0.5
        return float(fake_prob)
    except Exception as e:
        print(f"ViT error: {e}")
        return None


# ─────────────────────────────────────────────────────────────────
#  CLASSICAL FORENSICS (kept as supporting evidence)
# ─────────────────────────────────────────────────────────────────

def load_image(path):
    pil_img = Image.open(path).convert("RGB")
    cv_img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    return pil_img, cv_img


def analyze_ela(pil_img):
    try:
        qualities = [95, 90, 85, 80, 75]
        errors = []
        for quality in qualities:
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp:
                    tmp_path = tmp.name
                pil_img.save(tmp_path, 'JPEG', quality=quality)
                resaved = Image.open(tmp_path)
                diff = ImageChops.difference(pil_img, resaved.convert('RGB'))
                errors.append(np.mean(np.array(diff)))
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    os.unlink(tmp_path)

        avg_error = np.mean(errors)
        error_trend = np.polyfit(range(len(errors)), errors, 1)[0]
        suspicion = 0
        findings = []

        if avg_error < 3:
            suspicion += 0.6; findings.append("Very low ELA — AI-generated or heavily post-processed")
        elif avg_error < 8:
            suspicion += 0.3; findings.append("Below-normal ELA — possible AI generation")
        elif avg_error > 20:
            suspicion += 0.2; findings.append("High ELA — possible splicing")
        else:
            findings.append("ELA within normal range")

        if abs(error_trend) < 0.1:
            suspicion += 0.15; findings.append("Flat ELA trend — unnatural compression history")

        return {'suspicion': min(suspicion, 1.0), 'findings': findings, 'error_level': avg_error}
    except Exception as e:
        return {'suspicion': 0.3, 'findings': [f"ELA error: {e}"], 'error_level': 0}


def analyze_noise(cv_img):
    try:
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY).astype(np.float32)
        noise_levels = [
            np.std(gray - cv2.GaussianBlur(gray, ks, 0))
            for ks in [(3, 3), (5, 5), (7, 7)]
        ]
        noise_consistency = np.std(noise_levels) / (np.mean(noise_levels) + 1e-8)

        h, w = gray.shape
        block_size = 64
        block_noises = [
            np.std(gray[y:y+block_size, x:x+block_size]
                   - cv2.GaussianBlur(gray[y:y+block_size, x:x+block_size], (5, 5), 0))
            for y in range(0, h - block_size, block_size // 2)
            for x in range(0, w - block_size, block_size // 2)
        ]
        noise_uniformity = np.std(block_noises) / (np.mean(block_noises) + 1e-8)

        avg_noise = np.mean(noise_levels)
        suspicion = 0; findings = []

        if avg_noise < 1.0:
            suspicion += 0.5; findings.append("Very low noise — AI or heavy processing")
        elif avg_noise > 8:
            suspicion += 0.15; findings.append("High noise — low-light or compressed image")

        if noise_consistency < 0.1:
            suspicion += 0.3; findings.append("Noise too consistent across scales — AI artifact")
        elif noise_consistency > 0.5:
            suspicion += 0.15; findings.append("Inconsistent noise — possible splice")

        if noise_uniformity < 0.2:
            suspicion += 0.15; findings.append("Uniform noise pattern — typical of AI generation")
        elif noise_uniformity > 0.8:
            suspicion += 0.25; findings.append("Non-uniform noise — possible spliced regions")

        if not findings:
            findings.append("Natural noise pattern")

        return {'suspicion': min(suspicion, 1.0), 'findings': findings, 'noise_level': avg_noise}
    except Exception as e:
        return {'suspicion': 0.2, 'findings': [f"Noise error: {e}"], 'noise_level': 0}


def analyze_metadata(image_path):
    try:
        img = Image.open(image_path)
        try:
            exif_data = dict(img.getexif())
        except Exception:
            exif_data = {}

        suspicion = 0; findings = []
        if exif_data:
            findings.append("EXIF present — likely camera origin")
            for tag_id, value in exif_data.items():
                if not isinstance(value, (str, bytes)):
                    continue
                try:
                    vs = value.decode('utf-8', errors='ignore').lower() if isinstance(value, bytes) else str(value).lower()
                    if any(k in vs for k in ['photoshop', 'lightroom', 'gimp', 'affinity']):
                        findings.append(f"Editing software: {vs[:30]}"); suspicion += 0.25
                    if any(k in vs for k in ['stable diffusion', 'midjourney', 'dall-e', 'firefly', 'comfyui']):
                        findings.append(f"AI software in EXIF: {vs[:30]}"); suspicion += 0.9
                except Exception:
                    pass
        else:
            findings.append("No EXIF — common in AI / web images"); suspicion += 0.25

        file_size = os.path.getsize(image_path) / 1024
        w, h = img.size
        megapixels = (w * h) / 1_000_000
        if file_size < 100 and megapixels > 2:
            findings.append(f"Suspicious file size ({file_size:.0f} KB for {megapixels:.1f} MP)")
            suspicion += 0.15

        return {'suspicion': min(suspicion, 1.0), 'findings': findings, 'has_exif': bool(exif_data)}
    except Exception as e:
        return {'suspicion': 0.2, 'findings': [f"Metadata error: {e}"], 'has_exif': False}


def analyze_frequency(cv_img):
    try:
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
        f = np.fft.fft2(gray)
        fshift = np.fft.fftshift(f)
        magnitude = 20 * np.log(np.abs(fshift) + 1)
        magnitude = (magnitude - magnitude.min()) / (magnitude.max() - magnitude.min() + 1e-8)

        h, w = magnitude.shape
        cy, cx = h // 2, w // 2
        y, x = np.ogrid[-cy:h-cy, -cx:w-cx]
        radius = np.sqrt(x*x + y*y)
        max_r = min(cy, cx)

        rings = [
            np.mean(magnitude[(radius >= r) & (radius < r + 5)])
            for r in range(0, max_r, 5)
            if ((radius >= r) & (radius < r + 5)).any()
        ]
        peaks, _ = find_peaks(rings, height=0.1, distance=3)
        hf_energy = np.mean(magnitude[radius > max_r * 0.7])

        suspicion = 0; findings = []
        if len(peaks) > 8:
            suspicion += 0.6; findings.append(f"{len(peaks)} periodic FFT peaks — GAN artifact")
        elif len(peaks) > 4:
            suspicion += 0.25; findings.append("Periodic FFT peaks — possible AI")
        if hf_energy < 0.05:
            suspicion += 0.5; findings.append("Very low high-frequency energy — AI generated")
        elif hf_energy < 0.1:
            suspicion += 0.15; findings.append("Low high-frequency energy — possibly compressed")
        if not findings:
            findings.append("Normal frequency distribution")

        return {'suspicion': min(suspicion, 1.0), 'findings': findings, 'hf_energy': hf_energy}
    except Exception as e:
        return {'suspicion': 0.1, 'findings': [f"FFT error: {e}"], 'hf_energy': 0}


def analyze_texture(cv_img):
    try:
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
        radius = 3; n_points = 8 * radius
        lbp = local_binary_pattern(gray, n_points, radius, method='uniform')
        lbp_s = local_binary_pattern(gaussian(gray, sigma=1), n_points, radius, method='uniform')
        lbp_std = np.std(lbp)
        tex_cons = np.corrcoef(lbp.flatten(), lbp_s.flatten())[0, 1]

        suspicion = 0; findings = []
        if lbp_std < 5:
            suspicion += 0.5; findings.append("Very low texture variation — AI generated")
        elif lbp_std < 10:
            suspicion += 0.2; findings.append("Limited texture variation — possible AI")
        if tex_cons > 0.95:
            suspicion += 0.4; findings.append("Texture too consistent across scales")
        if not findings:
            findings.append("Natural texture patterns")

        return {'suspicion': min(suspicion, 1.0), 'findings': findings, 'tex_variation': lbp_std}
    except Exception as e:
        return {'suspicion': 0.2, 'findings': [f"Texture error: {e}"], 'tex_variation': 0}


# ─────────────────────────────────────────────────────────────────
#  ENSEMBLE VERDICT
# ─────────────────────────────────────────────────────────────────

def compute_verdict(pil_img, image_path, cv_img):
    """
    Weighted ensemble:
      • SigLIP  : 45 %  (highest accuracy model)
      • ViT-v2  : 35 %  (second DL model)
      • Classical: 20 %  (forensic support signals)

    If a DL model is unavailable its weight is redistributed.
    """

    # ── DL scores ────────────────────────────────────────────────
    siglip_fake = run_siglip(pil_img)   # None if unavailable
    vit_fake = run_vit(pil_img)

    # ── Classical forensics ───────────────────────────────────────
    classical = {
        'ela': analyze_ela(pil_img),
        'noise': analyze_noise(cv_img),
        'metadata': analyze_metadata(image_path),
        'frequency': analyze_frequency(cv_img),
        'texture': analyze_texture(cv_img),
    }
    classical_weights = {'ela': 0.20, 'noise': 0.25, 'metadata': 0.15,
                          'frequency': 0.20, 'texture': 0.20}
    classical_score = sum(
        classical[k]['suspicion'] * classical_weights[k]
        for k in classical_weights
    )  # 0–1

    # ── Weighted ensemble ─────────────────────────────────────────
    total_w = 0
    fake_score = 0.0

    if siglip_fake is not None:
        fake_score += siglip_fake * 0.45
        total_w += 0.45
    if vit_fake is not None:
        fake_score += vit_fake * 0.35
        total_w += 0.35

    classical_w = 1.0 - total_w  # whatever weight is left (always ≥ 0.20)
    fake_score += classical_score * classical_w
    # final normalised
    fake_pct = fake_score * 100   # 0–100

    # ── Verdict label ─────────────────────────────────────────────
    if fake_pct < 20:
        primary = "✅ Real Photo"; confidence = "High"
    elif fake_pct < 38:
        primary = "🟢 Likely Real"; confidence = "Medium"
    elif fake_pct < 55:
        primary = "🟡 Uncertain / Edited"; confidence = "Low"
    elif fake_pct < 72:
        primary = "🟠 Likely Fake / AI"; confidence = "Medium"
    else:
        primary = "🔴 Deepfake / AI-Generated"; confidence = "High"

    # ── Category breakdown ────────────────────────────────────────
    real_s = max(0.0, 100 - fake_pct * 1.15)
    df_s = fake_pct * 0.55
    ai_s = fake_pct * 0.35
    ed_s = fake_pct * 0.10
    total = real_s + df_s + ai_s + ed_s
    if total > 0:
        real_s, df_s, ai_s, ed_s = [v / total * 100 for v in (real_s, df_s, ai_s, ed_s)]

    rounded = [round(real_s), round(df_s), round(ai_s), round(ed_s)]
    diff = 100 - sum(rounded)
    if diff:
        rounded[[real_s, df_s, ai_s, ed_s].index(max(real_s, df_s, ai_s, ed_s))] += diff

    # ── All findings ──────────────────────────────────────────────
    all_findings = []
    for v in classical.values():
        all_findings.extend(v.get('findings', []))

    return {
        'fake_pct': round(fake_pct, 1),
        'primary': primary,
        'confidence': confidence,
        'findings': all_findings[:12],
        'siglip_fake': siglip_fake,
        'vit_fake': vit_fake,
        'classical_score': round(classical_score * 100, 1),
        'category_scores': {
            'real': rounded[0],
            'deepfake': rounded[1],
            'aigen': rounded[2],
            'edited': rounded[3],
        },
        'classical': classical,
    }


def engine_status():
    """Returns availability of each detection engine (used by /api/analyze response)."""
    return {
        'siglip': {'available': HAS_SIGLIP, 'name': 'SigLIP', 'reported_accuracy': 94.4},
        'vit': {'available': HAS_VIT, 'name': 'ViT-v2', 'reported_accuracy': 92.1},
        'classical': {'available': True, 'name': 'Classical Forensics (ELA/Noise/FFT/Texture/Metadata)'},
    }
