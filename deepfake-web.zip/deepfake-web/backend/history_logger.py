"""
history_logger.py
══════════════════════════════════════════════════════════════════
CSV-backed history log.

Replaces the original Tkinter app's in-memory `_history_log` list +
Toplevel Treeview window with a persistent CSV file, so history
survives server restarts and can be read by the React History page.

CSV columns: filename, timestamp, verdict, confidence, processing_time
(id is derived from row position and used for the /api/report/<id>
 and /api/result/<id> lookup — not stored in the CSV itself)
══════════════════════════════════════════════════════════════════
"""

import csv
import os
import threading

HISTORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "history.csv")
FIELDNAMES = ["filename", "timestamp", "verdict", "confidence", "processing_time"]

_lock = threading.Lock()


def _ensure_file():
    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
    if not os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()


def append_entry(filename, timestamp, verdict, confidence, processing_time):
    """Append one analysis result to the CSV log. Thread-safe."""
    _ensure_file()
    with _lock:
        with open(HISTORY_FILE, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writerow({
                "filename": filename,
                "timestamp": timestamp,
                "verdict": verdict,
                "confidence": confidence,
                "processing_time": processing_time,
            })


def read_all():
    """Returns all history rows as a list of dicts, each tagged with an `id`
    (its 1-based row position) so it can be referenced by /api/result/<id>."""
    _ensure_file()
    with _lock:
        with open(HISTORY_FILE, "r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

    entries = []
    for i, row in enumerate(rows):
        entries.append({"id": i, **row})
    return entries


def get_entry(entry_id):
    """Look up a single history row by id (its position in the CSV)."""
    entries = read_all()
    for entry in entries:
        if entry["id"] == entry_id:
            return entry
    return None
